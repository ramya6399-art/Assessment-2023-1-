function myNav() {
    var x = document.getElementById("myLinks");
    if (x.style.display === "flex") {
        x.style.display = "none";
    } else {
        x.style.display = "flex";
    }
}

function myForm() {
    alert("We Noted your Requirements. We'll shortly contact you. \n Thank you")
}

function enlargePic() {
    const showImage = document.getElementById("picSectionRight");
    const myImage = document.getElementById("img-new");
    showImage.addEventListener("click", () => {
        myImage.style.display = "block";
    });
}

/* Download Button scripting*/
document.querySelectorAll(".primary-btn").forEach((item) => {
    item.addEventListener("mouseover", (event) => {
        item.style.color = "black";
        item.style.backgroundColor = "#ffffff";
    });
    item.addEventListener("mouseout", (event) => {
        item.style.color = "#ffffff";
        item.style.backgroundColor = "transparent";
    });
});

/* Navigation Section Scripting Starts here*/

function featuredMsg() {
    document.getElementById("featu-nav").onclick = function () {
        alert("Please check our New Brand Features. ");
        location.href = '#awesomeSection';
    }
    document.getElementById("featu-navv").onclick = function () {
        alert("Please check our New Brand Features. ");
        location.href = '#awesomeSection';
    }
}

function aboutNavi() {
    document.getElementById('about-nav').onclick = function () {
        alert('Please go through our Social Media sites. \n Thank you!!');
        location.href = '#shareSection';
    }
    document.getElementById('about-navv').onclick = function () {
        alert('Please go through our Social Media sites. \n Thank you!!');
        location.href = '#shareSection';
    }
}

function pricingNavi() {
    document.getElementById('price-nav').onclick = function () {
        alert('Please Login to our Website. You can see the prices over there. \n Thank you!!');
        location.href = '#formm';
    }
    document.getElementById('price-navv').onclick = function () {
        alert('Please Login to our Website. You can see the prices over there. \n Thank you!!');
        location.href = '#formm';
    }
}

function reviewingNavi() {
    document.getElementById('review-nav').onclick = function () {
        alert('Here is our Sample Prototype. \n Please check now.');
        location.href = '#picSection';
    }
    document.getElementById('review-navv').onclick = function () {
        alert('Here is our Sample Prototype. \n Please check now.');
        location.href = '#picSection';
    }
}

function contactingNavi() {
    document.getElementById('contact-nav').onclick = function () {
        alert('Please contact us through the mentioned links. \n You will redirect to them. \n Thank you!!');
        location.href = '#axureSection';
    }
    document.getElementById('contact-navv').onclick = function () {
        alert('Please contact us through the mentioned links. \n You will redirect to them. \n Thank you!!');
        location.href = '#axureSection';
    }
}

featuredMsg();
aboutNavi();
pricingNavi();
reviewingNavi();
contactingNavi();

/* Navigation Section Scripting Ends Here */